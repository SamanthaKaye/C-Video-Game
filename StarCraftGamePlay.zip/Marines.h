#ifndef MARINE_H
#define MARINE_H

#include "Medics.h"
#include "Ghosts.h"

class marine: virtual public infantry
{
   public:
    marine(string xname="Unknown", string xteam="Unknown", string xtype="Marine", 
        int boost=10, int assualt=100, int no=0);  
    
    void setAssualtRifle(int);
    int getAssualtRifle() const;
        
    void fireAssualtRifle(infantry*);
    void renderAid(infantry*);

    virtual void attack (infantry*);
    virtual void die();
    
    virtual void print() const;
    virtual void display() const; 
     
   private:
      int assualt;      
      
};

#endif
