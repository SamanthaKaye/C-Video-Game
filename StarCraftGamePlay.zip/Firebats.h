#ifndef FIREBAT_H
#define FIREBAT_H

#include "Infantrys.h"

class firebat: virtual public infantry
{
    public:
        firebat(string xname="Unknown", string xteam="Unknown", string xtype="Firebat", 
                   int flameThrower=100);
                      
        void setFlameThrower(int);
        int getFlameThrower() const;

        void fireFlameThrower(infantry*);
        void renderAid(infantry*);
        
        virtual void attack (infantry*);
        virtual void die();

        virtual void print() const;
        virtual void display() const;
                
    private:
        int flameThrower;
        
};

#endif
