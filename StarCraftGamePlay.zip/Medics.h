#ifndef MEDIC_H
#define MEDIC_H

#include "Infantrys.h"

class medic: virtual public infantry
{
    public:
        medic(string xname="Unknown", string xteam="Unknown", string xtype="Medic", 
                   int boostedo=100, int =16);
                   
        void setBoosterShot(int);
        int getBoosterShot() const;
        
        void set_(int);
        int get_() const;

        void fire_boostedo(infantry*);
		void renderAid(infantry*);
        
        virtual void attack (infantry*);
        virtual void die();
        
        virtual void print() const;
        virtual void display() const;
                
    private:
        int boostedo;
            
};   

#endif

