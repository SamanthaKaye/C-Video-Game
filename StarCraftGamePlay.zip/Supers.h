#ifndef SUPER_H
#define SUPER_H

#include "Firebats.h"
#include "Marines.h"
#include "Ghosts.h"
#include "Medics.h"

class super: public firebat, public marine, public medic, public ghost
{
   public:
    super(string xname="Unknown",string xteam="Unknown", string xtype="Super", 
        int dbgun=4000, int bbgun=4000, int mgun=50, int b=10, int sniper=20, int c=10,
        int boost=30, int =12);  
    
    void setRocketLauncher(int);
    int getRocketLauncher() const;

    void setStickyGrenade(int);
    int getStickyGrenade() const;        

    void fireRocketLauncher(infantry*);
    void fireStickyGrenade(infantry*);
    void renderAid(infantry*);

    virtual void attack (infantry*);
    virtual void die();  
    
    virtual void print() const;
    virtual void display() const; 
     
      
   private:
      int rocket;
      int stickyGrenade;   
	     
      
};


#endif
