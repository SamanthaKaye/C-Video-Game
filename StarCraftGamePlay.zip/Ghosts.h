#ifndef GHOST_H
#define GHOST_H

#include "Infantrys.h"

class ghost: virtual public infantry
{
    public:
        ghost(string xname="Unknown", string xteam="Unknown", string xtype="Ghost", 
                int sniper=100);
        
        void setSniperRifle(int);
        int getSniperRifle() const;

        void fireSniperRifle(infantry*);
		void renderAid(infantry*);
     	virtual void sniperRifleHit(infantry*);
     	virtual void stickyGrenadeHit(infantry*);
     	virtual void assualtRifleHit(infantry*);
     	virtual void flameThrowerHit(infantry*);
        virtual void attack (infantry*);
        virtual void die();

        virtual void print() const;
        virtual void display() const;
                
    private:
        int sniperRifle;
       
    
};    

#endif
