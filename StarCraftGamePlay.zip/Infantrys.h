#ifndef INFANTRY_H
#define INFANTRY_H

#include <string>
#include <iomanip>

using namespace std;

class infantry
{
    public:
        infantry();
        infantry(string, string, string);
        
        void setName(string);
        string getName() const;
        
        void setType(string);
        string getType() const;
        
        void setHealth(int);
        int getHealth() const;
        
        void setTeam(string);
        string getTeam() const;
        
        static int getTotalBlueSoldiers();
        static int getTotalRedSoldiers();
                
        virtual void boostedo_hit();
        virtual void flameThrowerHit();
        virtual void assualtRifleHit();
        virtual void main_gun_hit(); 
        virtual void sniperRifleHit();
        virtual void stickyGrenadeHit();
        virtual void rocketLauncherHit();
        virtual void receiveAidFromGhost();
        virtual void receiveAidFromMarine();
        virtual void receiveAidFromMedic();
        virtual void receiveAidFromSuper();
                
        virtual void attack (infantry*)=0;
        virtual void renderAid (infantry*)=0;
        virtual void die()=0;
                
        virtual void print() const;
        virtual void display() const;
              
    private:
        string name;
        string type;
        string team;
        int health;
        
        static int totalBlueSoldiers;
        static int totalRedSoldiers;

};    


#endif

