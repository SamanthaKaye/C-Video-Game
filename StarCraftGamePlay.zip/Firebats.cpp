#include <iostream>

using namespace std;

#include "Firebats.h"

firebat::firebat(string xname, string xteam, string xtype, int flame)
                       : infantry(xname, xteam, xtype)
{
    setFlameThrower(flame);
    setHealth(100);
    cout << "Need a light? "<<endl;
}
        
void firebat::setFlameThrower(int flame)
{
    flameThrower = flame;
}

int firebat::getFlameThrower() const
{
    return flameThrower;
}
        
void firebat::fireFlameThrower(infantry* attackedInfantry)
{
    if(flameThrower!=0 && this->getHealth()!=0 && attackedInfantry->getHealth()!=0)
    {
        flameThrower--;
        attackedInfantry->flameThrowerHit();
    }    
}    
void firebat::renderAid(infantry* soldierBeingHelped)
{
  cout << "Sorry dude, I've got no first aid supplies. Keep thinking positive thoughts. ";  
} 

void firebat::attack (infantry* attackedInfantry)
{
    
    int x;
 
       fireFlameThrower(attackedInfantry);
       
    if (attackedInfantry->getHealth() == 0)
        attackedInfantry->die();
 
}    

void firebat::die()
{
    setFlameThrower(0);
}  

void firebat::print() const
{
    cout << endl;
    infantry::print();
    cout << "Flame Thrower Rounds: " << getFlameThrower() << endl;
    
} 


void firebat::display() const
{
  
         
    infantry::display();
    cout << right << setw(5) << getFlameThrower()
         << endl;
     
} 

